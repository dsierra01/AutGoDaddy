import static org.junit.jupiter.api.Assertions.*;
import java.io.IOException;

import org.junit.Test;
import org.junit.jupiter.api.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

class DataDrivenTest {
	
	
	
	@BeforeEach
	void setUp() throws Exception {
		
	}

	@AfterEach
	void tearDown() throws Exception {
		// driver.quit();
	}

	@Test
	void test() throws IOException {
		
	}

}
